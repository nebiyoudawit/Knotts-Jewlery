import express from 'express';
import { updateUserProfile, changeUserPassword } from '../controllers/userController.js';
import { authMiddleware } from '../middleware/authMiddleware.js'; // Only import authMiddleware

const router = express.Router();

// User routes (private routes)
router.put('/update', authMiddleware, updateUserProfile); // User can update their profile
router.put('/change-password', authMiddleware, changeUserPassword); // User can change their password



export default router;
