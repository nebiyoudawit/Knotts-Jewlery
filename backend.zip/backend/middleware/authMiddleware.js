import { verifyToken } from '../utils/jwtUtils.js';
import User from '../models/User.model.js';

// Protect routes - requires valid JWT
export const protect = async (req, res, next) => {
  try {
    // 1) Get token from header
    const token = req.header('x-auth-token');
    
    if (!token) {
      return res.status(401).json({ message: 'No token, authorization denied' });
    }

    // 2) Verify token
    const decoded = verifyToken(token);

    // 3) Get user from token
    req.user = await User.findById(decoded.id).select('-password');
    next();

  } catch (error) {
    res.status(401).json({ message: 'Token is not valid' });
  }
};

// Restrict to admin
export const admin = (req, res, next) => {
  if (req.user && req.user.role === 'admin') {
    next();
  } else {
    res.status(403).json({ message: 'Not authorized as admin' });
  }
};