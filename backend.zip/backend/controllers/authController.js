import User from '../models/users.js';
import jwt from 'jsonwebtoken';
import dotenv from 'dotenv';

dotenv.config();

// Helper function
const signToken = (id, role) => {
  return jwt.sign({ id, role }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN
  });
};

export const login = async (req, res) => {
  try {
    const { email, password, isAdmin } = req.body;
    
    // 1) Check if user exists
    const user = await User.findOne({ email }).select('+password');
    if (!user) {
      return res.status(401).json({
        status: 'fail',
        message: 'Invalid email or password'
      });
    }

    // 2) Check if password is correct
    const correct = await user.comparePassword(password);
    if (!correct) {
      return res.status(401).json({
        status: 'fail',
        message: 'Invalid email or password'
      });
    }

    // 3) If admin login, verify role
    if (isAdmin && user.role !== 'admin') {
      return res.status(403).json({
        status: 'fail',
        message: 'Not authorized as admin'
      });
    }

    // 4) Generate token
    const token = signToken(user._id, user.role);

    // 5) Send response
    res.status(200).json({
      status: 'success',
      token,
      user: {
        _id: user._id,
        name: user.name,
        email: user.email,
        role: user.role
      }
    });

  } catch (err) {
    res.status(400).json({
      status: 'error',
      message: err.message
    });
  }
};

export const register = async (req, res) => {
  try {
    const { name, email, password, address, phone } = req.body;

    // 1) Check if user exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({
        status: 'fail',
        message: 'Email already in use'
      });
    }

    // 2) Create new user
    const newUser = await User.create({
      name,
      email,
      password,
      address,
      phone,
      role: 'customer' // Default role
    });

    // 3) Generate token
    const token = signToken(newUser._id, newUser.role);

    // 4) Send response
    res.status(201).json({
      status: 'success',
      token,
      user: {
        _id: newUser._id,
        name: newUser.name,
        email: newUser.email,
        role: newUser.role
      }
    });

  } catch (err) {
    res.status(400).json({
      status: 'error',
      message: err.message
    });
  }
};